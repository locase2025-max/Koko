---
name: Questions/Support requests/Other
about: You should probably use the forum
title: ''
labels: question
assignees: ''

---

Please use the forum at https://discourse.shadowsocks.org/c/implementations/shadowsocks-android instead. Your issue will probably be closed.
